# GW2 Net et Stable – preset ReShade pour Guild Wars 2

Un preset léger, pensé pour jouer, centré sur **la netteté et le minimum d'aliasing** plutôt que sur l'étalonnage des couleurs.
Il respecte la direction artistique de GW2 et nettoie surtout les bords crénelés et le scintillement en mouvement.

**Conçu pour :** 2560 × 1440, taille d'interface « Normale ». Compatible avec la génération d'images de Lossless Scaling.

## Chaîne d'effets

| Ordre | Effet | Rôle |
|---|---|---|
| 1 | UIMask_Top | Sauvegarde le HUD avant tout traitement |
| 2 | iMMERSE: MXAO | Ombres de contact discrètes, en complément de l'AO du jeu |
| 3 | iMMERSE: Anti Aliasing (SMAA) | Rattrape les bords que le SMAA du jeu laisse passer |
| 4 | Zenteon: Motion | Vecteurs de mouvement pour la passe temporelle |
| 5 | Zenteon: ATA (BETA) | Réduit le scintillement en mouvement (feuillage, armure, lignes fines) |
| 6 | iMMERSE: Sharpen | Netteté qui tient compte de la profondeur et épargne les silhouettes |
| 7 | UIMask_Bottom | Recolle un HUD net et intact |

## Prérequis

- **ReShade avec support complet des add-ons** (dernière version sur reshade.me)
- Packs d'effets (à cocher dans l'installeur de ReShade) :
  - **iMMERSE** de Marty McFly (MXAO, SMAA, Sharpen)
  - **ZenteonFX** de Zenteon (Motion, ATA)
  - **Effets standard** de crosire (UIMask)

## Installation

1. Extrais cette archive **dans le dossier de Guild Wars 2** (par exemple `C:\Program Files\Guild Wars 2`).
   Le fichier `.ini` du preset se place à côté de `Gw2-64.exe`, le masque va dans `reshade-shaders\Textures`.
2. Lance l'installeur de ReShade, sélectionne `Gw2-64.exe`, choisis **DirectX 10/11/12**.
3. Quand il demande un preset, pointe vers le `.ini` de cette archive : l'installeur cochera automatiquement les packs d'effets nécessaires.
4. Lance le jeu, ouvre ReShade (touche Début) et sélectionne le preset dans la liste en haut.
5. Dans UIMask_Bottom, coche une fois **Display Mask** : des rectangles blancs doivent recouvrir exactement ton HUD. Décoche ensuite.

**Si ReShade ne se charge pas :** renomme `dxgi.dll` en `d3d11.dll` dans le dossier du jeu.

## Réglages en jeu recommandés (F11)

| Réglage | Valeur |
|---|---|
| Anticrénelage | SMAA élevé |
| Échantillonnage du rendu | Super échantillon |
| Occlusion ambiante | Activée |
| Flou lumineux, Distorsion, Floutage d'arrière-plan, Adaptation à la lumière | Désactivés |
| Intensité du flou cinétique | Minimum |
| Réflexions | Aucune (gros gain CPU) |
| Limite / Qualité des modèles de personnages | À baisser en méta |

## Remarques

- **Le masque du HUD n'est valable qu'en 2560 × 1440 avec une interface « Normale ».** Pour une autre résolution ou taille d'interface, il faut refaire le masque (rectangles blancs sur fond noir, à la taille exacte de l'écran).
- Les éléments mobiles non masqués (chiffres de dégâts, noms) peuvent paraître un peu doux en mouvement à cause de la passe temporelle.
- Un peu de traînée en mouvement ? Baisse l'**Accumulation value** d'ATA (0,80 → 0,75) ou passe en mode **NonLocal** avec `ACCUMULATION_QUALITY` à 0.
- ArenaNet ne valide aucun programme tiers. ReShade est très utilisé sur GW2, mais son usage reste à tes risques.

## Crédits

- Marty McFly – iMMERSE (MXAO, SMAA, Sharpen)
- Zenteon – ZenteonFX (Motion, ATA)
- crosire – ReShade et UIMask

## Historique

- **v1.0** – Première version
