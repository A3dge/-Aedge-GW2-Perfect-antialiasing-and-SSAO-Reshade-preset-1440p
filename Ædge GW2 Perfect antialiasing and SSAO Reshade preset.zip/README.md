# GW2 Clean & Sharp – ReShade preset for Guild Wars 2

A lightweight, gameplay-oriented preset focused on **sharpness and minimal aliasing**, not on color grading.
It keeps GW2's art style intact and mostly cleans up jagged edges and shimmering in motion.

**Made for:** 2560 × 1440, in-game interface size "Normal". Works well with Lossless Scaling frame generation.

## What it does

| Order | Effect | Role |
|---|---|---|
| 1 | UIMask_Top | Saves the HUD before any processing |
| 2 | iMMERSE: MXAO | Subtle contact shadows on top of the in-game AO |
| 3 | iMMERSE: Anti Aliasing (SMAA) | Catches edges the in-game SMAA misses |
| 4 | Zenteon: Motion | Motion vectors for the temporal pass |
| 5 | Zenteon: ATA (BETA) | Reduces shimmering in motion (foliage, armor, thin lines) |
| 6 | iMMERSE: Sharpen | Depth-aware sharpening that leaves silhouettes alone |
| 7 | UIMask_Bottom | Restores a crisp, untouched HUD |

## Requirements

- **ReShade with full add-on support** (latest version from reshade.me)
- Effect packages (select them in the ReShade installer):
  - **iMMERSE** by Marty McFly (MXAO, SMAA, Sharpen)
  - **ZenteonFX** by Zenteon (Motion, ATA)
  - **Standard effects** by crosire (UIMask)

## Installation

1. Extract this archive **into your Guild Wars 2 folder** (e.g. `C:\Program Files\Guild Wars 2`).
   The preset `.ini` goes next to `Gw2-64.exe`, the mask goes into `reshade-shaders\Textures`.
2. Run the ReShade installer, select `Gw2-64.exe`, choose **DirectX 10/11/12**.
3. When asked for a preset, browse to the preset `.ini` from this archive: the installer will tick the required effect packages for you.
4. Launch the game, open ReShade (Home key) and select the preset in the dropdown at the top.
5. Open UIMask_Bottom and tick **Display Mask** once: white boxes should sit exactly on your HUD. Untick it afterwards.

**If ReShade does not load:** rename `dxgi.dll` to `d3d11.dll` in the game folder.

## Recommended in-game settings (F11)

| Setting | Value |
|---|---|
| Antialiasing | SMAA High |
| Render Sampling | Supersample |
| Ambient Occlusion | On |
| Bloom, Distortion, Depth Blur, Light Adaptation | Off |
| Motion Blur Power | Minimum |
| Reflections | None (big CPU saving) |
| Character Model Limit / Quality | Lower them in crowded metas |

## Notes

- **The HUD mask only fits 2560 × 1440 with interface size "Normal".** Other resolutions or UI sizes need a new mask (paint white boxes over your HUD on a black 1:1 screenshot-sized PNG).
- Moving elements that are not masked (damage numbers, nameplates) can look slightly soft in motion because of the temporal pass.
- A bit of trailing in motion? Lower ATA's **Accumulation value** (0.80 → 0.75) or switch to **NonLocal** mode with `ACCUMULATION_QUALITY` set to 0.
- ArenaNet does not endorse any third-party program. ReShade is widely used in GW2, but use it at your own risk.

## Credits

- Marty McFly – iMMERSE (MXAO, SMAA, Sharpen)
- Zenteon – ZenteonFX (Motion, ATA)
- crosire – ReShade and UIMask

## Changelog

- **v1.0** – Initial release
